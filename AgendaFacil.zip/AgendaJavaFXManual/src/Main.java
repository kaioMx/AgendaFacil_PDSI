import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Main extends Application {

    private final ObservableList<Tarefa> tarefas = FXCollections.observableArrayList();
    private final ListView<Tarefa> listView = new ListView<>(tarefas);

    @Override
    public void start(Stage stage) {
        stage.setTitle("Agenda JavaFX");

        TextField input = new TextField();
        input.setPromptText("Digite uma nova tarefa");

        TextField filtro = new TextField();
        filtro.setPromptText("Buscar tarefa");

        Label mensagemErro = new Label();
        mensagemErro.setTextFill(Color.RED);

        Button adicionarBtn = new Button("Adicionar");
        Button excluirBtn = new Button("Excluir selecionada");

        adicionarBtn.setOnAction(e -> {
            String texto = input.getText().trim();
            if (!texto.isEmpty()) {
                tarefas.add(new Tarefa(texto));
                input.clear();
                mensagemErro.setText("");
                filtrarTarefas(filtro.getText());
            }
        });

        excluirBtn.setOnAction(e -> {
            Tarefa selecionada = listView.getSelectionModel().getSelectedItem();
            if (selecionada != null) {
                tarefas.remove(selecionada);
                filtrarTarefas(filtro.getText());
                mensagemErro.setText("");
            }
        });

        filtro.textProperty().addListener((obs, oldVal, newVal) -> filtrarTarefas(newVal));
        filtro.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                filtrarTarefas(filtro.getText());
            }
        });

        VBox layout = new VBox(10, input, adicionarBtn, filtro, listView, excluirBtn, mensagemErro);
        layout.setPadding(new Insets(15));
        layout.setStyle("-fx-background-color: #e0f0ff;");

        Scene scene = new Scene(layout, 400, 500);
        stage.setScene(scene);
        stage.show();
    }

    private void filtrarTarefas(String texto) {
        ObservableList<Tarefa> filtradas = FXCollections.observableArrayList();
        for (Tarefa t : tarefas) {
            if (t.getDescricao().toLowerCase().contains(texto.toLowerCase())) {
                filtradas.add(t);
            }
        }
        listView.setItems(filtradas);
        if (filtradas.isEmpty() && !texto.isEmpty()) {
            listView.setPlaceholder(new Label("Tarefa não encontrada."));
        } else {
            listView.setPlaceholder(new Label("Nenhuma tarefa adicionada."));
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}